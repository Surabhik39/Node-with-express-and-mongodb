var http = require('http');
var express = require('express');
var exp = express();
var parser = require('body-parser')
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;

/***************************Get all data********************************** */
exp.get('/rest/api/readfile',cors(),(req,res)=>{
    var dataInFile;
    fs.readFile('demo.json',function(err,data){
     //   res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
        console.log(dataInFile);
        res.send(dataInFile);
    });
});

/********************************Display state vice data*************************************** */
exp.get('/rest/api/getstate',cors(),(req,res)=>{
    var dataInFile;
    var block=[];
    fs.readFile('demo.json',function(err,data){
       // res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
            for(i=0;i<dataInFile.length;i++)
            {
                if(dataInFile[i].empAddress.state=="Maharashtra")
                {
                    block[i]=dataInFile[i];
                }
            }
             console.log(block);
           res.send(block)
        res.end();
    });
})


/********************************Update city of employee************************************** */

exp.use(parser.json());
exp.route('/rest/api/putdata/:id/:city',cors()).put((req,res)=>{
    console.log(req.params.id)
    console.log(req.params.city)

   fs.readFile('demo.json',function(err,data){
       // res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
            for(i=0;i<dataInFile.length;i++)
            {
                if(dataInFile[i].empId==req.params.id)
                {
                    dataInFile[i].empAddress.city=req.params.city;
                }
            }
           res.send(dataInFile)
        res.end();
    });
})


/************************************Adding a new employee*************************************** */
exp.route('/rest/api/post', cors()).post((req, res) => {

 fs.readFile('demo.json',function(err,data){
       // res.writeHead(200,{'Content-Type':'text/plain'});
        dataInFile = JSON.parse(data.toLocaleString());
            
    var obj={"empId":1007,"empName":"surabhi","empSalary":40800,"empAddress":{"city":"Ich","state":"Maharashtra"}};
    dataInFile.push(obj);
    console.log(dataInFile)
    fs.writeFileSync('demo.json',JSON.stringify(dataInFile))
    res.send(dataInFile)
    res.end()

});
})

/************************************************************************************************* */
exp.use(cors()).listen(3002, () => console.log("RUNNING...."));